package fr.umlv.thaw.user;

/**
 * This interface represent a User that can be a
 * human or a bot
 */
public interface User {


    /**
     * @return the user name
     */
    String getName();


}
