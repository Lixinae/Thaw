/*
 * Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package com.sun.jmx.snmp.defaults;

import java.util.logging.Logger;

public class Utils {
    public static final Logger SNMP_LOGGER =
            Logger.getLogger("javax.management.snmp");
    public static final Logger SNMP_ADAPTOR_LOGGER =
            Logger.getLogger("javax.management.snmp.daemon");

    private Utils() {}

    // copied from com.sun.jmx.mbeanserver.Util
    @SuppressWarnings("unchecked")
    public static <T> T cast(Object x) {
        return (T) x;
    }
}
